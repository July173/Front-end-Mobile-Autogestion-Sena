# ============================================
# Script de pruebas automatizadas
# AutoGestión SENA - Endpoints API
# ============================================

$baseUrl = "http://192.168.1.18:8000/api"
$testEmail = "bscortes40@soy.sena.edu.co"
$testPassword = "1129844804"

Write-Host "`n" -NoNewline
Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  PRUEBAS AUTOMATIZADAS - API ENDPOINTS  ║" -ForegroundColor Cyan
Write-Host "║      AutoGestión SENA - CIES            ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

$totalTests = 0
$passedTests = 0
$failedTests = 0

# Función para mostrar resultados
function Show-TestResult {
    param(
        [string]$TestName,
        [bool]$Success,
        [int]$StatusCode = 0,
        [object]$Response = $null,
        [string]$ErrorMessage = ""
    )
    
    $script:totalTests++
    
    if ($Success) {
        $script:passedTests++
        Write-Host "  [✓] " -NoNewline -ForegroundColor Green
        Write-Host "$TestName" -ForegroundColor White
        Write-Host "      Status: $StatusCode" -ForegroundColor DarkGray
        
        if ($Response) {
            Write-Host "      Datos recibidos:" -ForegroundColor DarkGray
            if ($Response -is [array]) {
                Write-Host "      - Elementos: $($Response.Count)" -ForegroundColor DarkGray
            } elseif ($Response.PSObject.Properties) {
                $Response.PSObject.Properties | Select-Object -First 3 | ForEach-Object {
                    Write-Host "      - $($_.Name): $($_.Value)" -ForegroundColor DarkGray
                }
            }
        }
    } else {
        $script:failedTests++
        Write-Host "  [✗] " -NoNewline -ForegroundColor Red
        Write-Host "$TestName" -ForegroundColor White
        if ($StatusCode -gt 0) {
            Write-Host "      Status: $StatusCode" -ForegroundColor DarkGray
        }
        if ($ErrorMessage) {
            Write-Host "      Error: $ErrorMessage" -ForegroundColor Red
        }
    }
    Write-Host ""
}

# ============================================
# TEST 1: Obtener tipos de documento
# ============================================
Write-Host "📋 TEST 1: Obtener tipos de documento" -ForegroundColor Yellow
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/security/document-types/" -Method Get -ContentType "application/json"
    Show-TestResult -TestName "GET /security/document-types/" -Success $true -StatusCode 200 -Response $response
} catch {
    Show-TestResult -TestName "GET /security/document-types/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -ErrorMessage $_.Exception.Message
}

# ============================================
# TEST 2: Validar login institucional
# ============================================
Write-Host "🔐 TEST 2: Validar login institucional" -ForegroundColor Yellow
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray
Write-Host "   Usuario: $testEmail" -ForegroundColor DarkGray
try {
    $loginBody = @{
        email = $testEmail
        password = $testPassword
    } | ConvertTo-Json
    
    $response = Invoke-RestMethod -Uri "$baseUrl/security/users/validate-institutional-login/" -Method Post -Body $loginBody -ContentType "application/json"
    
    if ($response.error) {
        Show-TestResult -TestName "POST /security/users/validate-institutional-login/" -Success $false -StatusCode 200 -ErrorMessage $response.error
    } else {
        Show-TestResult -TestName "POST /security/users/validate-institutional-login/" -Success $true -StatusCode 200 -Response $response
        $script:loginSuccess = $true
        $script:userEmail = $testEmail
        
        # Guardar tokens si existen
        if ($response.access) {
            $script:accessToken = $response.access
            Write-Host "      ✓ Token de acceso recibido" -ForegroundColor Green
        }
    }
} catch {
    $errorMsg = if ($_.ErrorDetails.Message) { $_.ErrorDetails.Message } else { $_.Exception.Message }
    Show-TestResult -TestName "POST /security/users/validate-institutional-login/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -ErrorMessage $errorMsg
}

# ============================================
# TEST 3: Validar código 2FA (Interactivo)
# ============================================
if ($script:loginSuccess) {
    Write-Host "🔢 TEST 3: Validar código de segundo factor" -ForegroundColor Yellow
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray
    Write-Host "   Se ha enviado un código de 6 dígitos al correo: $testEmail" -ForegroundColor Cyan
    $code = Read-Host "   Ingresa el código recibido"
    
    try {
        $twoFactorBody = @{
            email = $script:userEmail
            code = $code
        } | ConvertTo-Json
        
        $response = Invoke-RestMethod -Uri "$baseUrl/security/users/validate-2fa-code/" -Method Post -Body $twoFactorBody -ContentType "application/json"
        Show-TestResult -TestName "POST /security/users/validate-2fa-code/" -Success $true -StatusCode 200 -Response $response
        
        if ($response.access) {
            $script:accessToken = $response.access
            Write-Host "      ✓ Token JWT actualizado" -ForegroundColor Green
        }
    } catch {
        $errorMsg = if ($_.ErrorDetails.Message) { $_.ErrorDetails.Message } else { $_.Exception.Message }
        Show-TestResult -TestName "POST /security/users/validate-2fa-code/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -ErrorMessage $errorMsg
    }
}

# ============================================
# TEST 4: Registro de aprendiz (Opcional)
# ============================================
Write-Host "👤 TEST 4: Registro de aprendiz" -ForegroundColor Yellow
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray
$testRegister = Read-Host "   ¿Deseas probar el registro de un nuevo aprendiz? (S/N)"

if ($testRegister -eq "S" -or $testRegister -eq "s") {
    Write-Host "   Ingresa los datos del aprendiz:" -ForegroundColor Cyan
    $regEmail = Read-Host "   Email institucional"
    $firstName = Read-Host "   Primer nombre"
    $firstLastName = Read-Host "   Primer apellido"
    $typeId = Read-Host "   Tipo de documento (1=CC, 2=TI, 3=CE)"
    $numberId = Read-Host "   Número de documento"
    $phone = Read-Host "   Teléfono"
    
    try {
        $registerBody = @{
            email = $regEmail
            first_name = $firstName
            first_last_name = $firstLastName
            type_identification = [int]$typeId
            number_identification = [int]$numberId
            phone_number = [int]$phone
        } | ConvertTo-Json
        
        $response = Invoke-RestMethod -Uri "$baseUrl/security/persons/register-apprentice/" -Method Post -Body $registerBody -ContentType "application/json"
        Show-TestResult -TestName "POST /security/persons/register-apprentice/" -Success $true -StatusCode 200 -Response $response
    } catch {
        $errorMsg = if ($_.ErrorDetails.Message) { $_.ErrorDetails.Message } else { $_.Exception.Message }
        Show-TestResult -TestName "POST /security/persons/register-apprentice/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -ErrorMessage $errorMsg
    }
} else {
    Write-Host "   [⊘] Test omitido por el usuario" -ForegroundColor Yellow
    Write-Host ""
}

# ============================================
# TEST 5: Recuperación de contraseña (Opcional)
# ============================================
Write-Host "🔑 TEST 5: Solicitud de recuperación de contraseña" -ForegroundColor Yellow
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray
$testReset = Read-Host "   ¿Deseas probar la recuperación de contraseña? (S/N)"

if ($testReset -eq "S" -or $testReset -eq "s") {
    $resetEmail = Read-Host "   Email institucional"
    
    try {
        $resetBody = @{
            email = $resetEmail
        } | ConvertTo-Json
        
        $response = Invoke-RestMethod -Uri "$baseUrl/security/users/request-password-reset/" -Method Post -Body $resetBody -ContentType "application/json"
        Show-TestResult -TestName "POST /security/users/request-password-reset/" -Success $true -StatusCode 200 -Response $response
    } catch {
        $errorMsg = if ($_.ErrorDetails.Message) { $_.ErrorDetails.Message } else { $_.Exception.Message }
        Show-TestResult -TestName "POST /security/users/request-password-reset/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -ErrorMessage $errorMsg
    }
} else {
    Write-Host "   [⊘] Test omitido por el usuario" -ForegroundColor Yellow
    Write-Host ""
}

# ============================================
# RESUMEN DE PRUEBAS
# ============================================
Write-Host ""
Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║           RESUMEN DE PRUEBAS            ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Total de pruebas: $totalTests" -ForegroundColor White
Write-Host "  Exitosas: " -NoNewline -ForegroundColor White
Write-Host "$passedTests" -ForegroundColor Green
Write-Host "  Fallidas: " -NoNewline -ForegroundColor White
Write-Host "$failedTests" -ForegroundColor Red

if ($failedTests -eq 0) {
    Write-Host ""
    Write-Host "  🎉 ¡Todas las pruebas pasaron exitosamente!" -ForegroundColor Green
} else {
    Write-Host ""
    Write-Host "  ⚠️  Algunas pruebas fallaron. Revisa los detalles arriba." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor DarkGray
Write-Host ""
