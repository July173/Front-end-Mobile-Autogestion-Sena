# Prueba de Login con 2FA - AutoGestión SENA
# Usuario: bscortes40@soy.sena.edu.co

$baseUrl = "http://192.168.1.18:8000/api"
$email = "bscortes40@soy.sena.edu.co"
$password = "1129844804"

Write-Host "`n==========================================" -ForegroundColor Cyan
Write-Host "PRUEBA DE LOGIN CON 2FA" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "Usuario: $email" -ForegroundColor Yellow
Write-Host ""

# PASO 1: Login institucional
Write-Host "PASO 1: Enviando credenciales..." -ForegroundColor Yellow
try {
    $loginBody = @{
        email = $email
        password = $password
    } | ConvertTo-Json

    Write-Host "Endpoint: POST $baseUrl/security/users/validate-institutional-login/" -ForegroundColor Gray
    Write-Host "Body: $loginBody" -ForegroundColor Gray
    Write-Host ""

    $loginResponse = Invoke-RestMethod -Uri "$baseUrl/security/users/validate-institutional-login/" -Method Post -Body $loginBody -ContentType "application/json"
    
    Write-Host "[✓] Login exitoso - Código 2FA enviado al correo" -ForegroundColor Green
    Write-Host ""
    $loginResponse | ConvertTo-Json -Depth 5
    Write-Host ""
    
    # PASO 2: Solicitar código 2FA
    Write-Host "PASO 2: Validación de código 2FA" -ForegroundColor Yellow
    Write-Host "Revisa tu correo: $email" -ForegroundColor Cyan
    $code = Read-Host "Ingresa el código de 6 dígitos"
    
    if ($code.Length -eq 6) {
        $twoFactorBody = @{
            email = $email
            code = $code
        } | ConvertTo-Json
        
        Write-Host ""
        Write-Host "Endpoint: POST $baseUrl/security/users/validate-2fa-code/" -ForegroundColor Gray
        Write-Host "Body: $twoFactorBody" -ForegroundColor Gray
        Write-Host ""
        
        $twoFactorResponse = Invoke-RestMethod -Uri "$baseUrl/security/users/validate-2fa-code/" -Method Post -Body $twoFactorBody -ContentType "application/json"
        
        Write-Host "[✓] Código 2FA validado correctamente" -ForegroundColor Green
        Write-Host ""
        Write-Host "========== TOKENS OBTENIDOS ==========" -ForegroundColor Green
        Write-Host "Access Token:" -ForegroundColor Yellow
        Write-Host $twoFactorResponse.access -ForegroundColor White
        Write-Host ""
        Write-Host "Refresh Token:" -ForegroundColor Yellow
        Write-Host $twoFactorResponse.refresh -ForegroundColor White
        Write-Host ""
        Write-Host "Información del usuario:" -ForegroundColor Yellow
        $twoFactorResponse.user | ConvertTo-Json -Depth 5
        Write-Host ""
        
        Write-Host "[✓] PRUEBA EXITOSA - Login completado con 2FA" -ForegroundColor Green
        
    } else {
        Write-Host "[✗] El código debe tener 6 dígitos" -ForegroundColor Red
    }
    
} catch {
    Write-Host "[✗] Error en el login" -ForegroundColor Red
    Write-Host "Status Code: $($_.Exception.Response.StatusCode.value__)" -ForegroundColor Red
    Write-Host "Mensaje: $($_.ErrorDetails.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
