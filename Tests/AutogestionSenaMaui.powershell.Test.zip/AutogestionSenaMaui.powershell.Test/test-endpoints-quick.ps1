# Pruebas rápidas de endpoints individuales
# Uso: Copia y pega el comando que quieras probar

$baseUrl = "http://192.168.1.18:8000/api"

# ========================================
# 1. GET - Obtener tipos de documento
# ========================================
Write-Host "`n📋 TEST: Tipos de documento" -ForegroundColor Cyan
$response = Invoke-WebRequest -Uri "$baseUrl/security/document-types/" -Method Get
Write-Host "Status: $($response.StatusCode)" -ForegroundColor Green
$response.Content | ConvertFrom-Json | Format-Table -AutoSize

# ========================================
# 2. POST - Validar login
# ========================================
Write-Host "`n🔐 TEST: Validar login" -ForegroundColor Cyan
$loginBody = @{
    email = "TU_EMAIL@soy.sena.edu.co"
    password = "TU_CONTRASEÑA"
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$baseUrl/security/users/validate-institutional-login/" -Method Post -Body $loginBody -ContentType "application/json"
    Write-Host "✓ Login exitoso" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 5
} catch {
    Write-Host "✗ Error en login: $($_.Exception.Message)" -ForegroundColor Red
    $_.ErrorDetails.Message
}

# ========================================
# 3. POST - Validar código 2FA
# ========================================
Write-Host "`n🔢 TEST: Validar código 2FA" -ForegroundColor Cyan
$twoFactorBody = @{
    email = "TU_EMAIL@soy.sena.edu.co"
    code = "123456"  # Código de 6 dígitos recibido por email
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$baseUrl/security/users/validate-2fa-code/" -Method Post -Body $twoFactorBody -ContentType "application/json"
    Write-Host "✓ Código validado" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 5
} catch {
    Write-Host "✗ Error en validación 2FA: $($_.Exception.Message)" -ForegroundColor Red
    $_.ErrorDetails.Message
}

# ========================================
# 4. POST - Registrar aprendiz
# ========================================
Write-Host "`n👤 TEST: Registrar aprendiz" -ForegroundColor Cyan
$registerBody = @{
    email = "nuevo.aprendiz@soy.sena.edu.co"
    first_name = "Juan"
    second_name = "Carlos"
    first_last_name = "Pérez"
    second_last_name = "García"
    type_identification = 1  # 1 = Cédula de Ciudadanía
    number_identification = 1234567890
    phone_number = 3001234567
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$baseUrl/security/persons/register-apprentice/" -Method Post -Body $registerBody -ContentType "application/json"
    Write-Host "✓ Registro exitoso" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 5
} catch {
    Write-Host "✗ Error en registro: $($_.Exception.Message)" -ForegroundColor Red
    $_.ErrorDetails.Message
}

# ========================================
# 5. POST - Solicitar recuperación de contraseña
# ========================================
Write-Host "`n🔑 TEST: Recuperar contraseña" -ForegroundColor Cyan
$resetBody = @{
    email = "TU_EMAIL@soy.sena.edu.co"
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$baseUrl/security/users/request-password-reset/" -Method Post -Body $resetBody -ContentType "application/json"
    Write-Host "✓ Solicitud enviada" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 5
} catch {
    Write-Host "✗ Error en recuperación: $($_.Exception.Message)" -ForegroundColor Red
    $_.ErrorDetails.Message
}

# ========================================
# 6. POST - Resetear contraseña
# ========================================
Write-Host "`n🔐 TEST: Resetear contraseña" -ForegroundColor Cyan
$resetPasswordBody = @{
    email = "TU_EMAIL@soy.sena.edu.co"
    code = "123456"  # Código recibido por email
    new_password = "NuevaContraseña123!"
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$baseUrl/security/users/reset-password/" -Method Post -Body $resetPasswordBody -ContentType "application/json"
    Write-Host "✓ Contraseña reseteada" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 5
} catch {
    Write-Host "✗ Error al resetear: $($_.Exception.Message)" -ForegroundColor Red
    $_.ErrorDetails.Message
}

Write-Host "`n✅ Pruebas completadas" -ForegroundColor Green
