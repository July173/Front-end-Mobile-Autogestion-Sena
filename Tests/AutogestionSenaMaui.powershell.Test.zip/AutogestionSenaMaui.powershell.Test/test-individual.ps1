# ============================================
# Pruebas individuales de endpoints
# Uso: Ejecuta cada bloque según lo necesites
# ============================================

$baseUrl = "http://192.168.1.18:8000/api"

# Credenciales de prueba
$email = "bscortes40@soy.sena.edu.co"
$password = "1129844804"

# ============================================
# TEST 1: Tipos de documento
# ============================================
Write-Host "`n📋 Obteniendo tipos de documento..." -ForegroundColor Cyan
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/security/document-types/" -Method Get
    Write-Host "✓ Éxito - $($response.Count) tipos encontrados" -ForegroundColor Green
    $response | Format-Table id, name, acronyms, active -AutoSize
} catch {
    Write-Host "✗ Error: $($_.Exception.Message)" -ForegroundColor Red
}

# ============================================
# TEST 2: Login
# ============================================
Write-Host "`n🔐 Probando login..." -ForegroundColor Cyan
Write-Host "Usuario: $email" -ForegroundColor Gray
try {
    $body = @{
        email = $email
        password = $password
    } | ConvertTo-Json
    
    $response = Invoke-RestMethod -Uri "$baseUrl/security/users/validate-institutional-login/" -Method Post -Body $body -ContentType "application/json"
    
    if ($response.error) {
        Write-Host "✗ Error: $($response.error)" -ForegroundColor Red
    } else {
        Write-Host "✓ Login exitoso" -ForegroundColor Green
        Write-Host "Detalles:" -ForegroundColor Gray
        $response | ConvertTo-Json -Depth 3
        
        # Guardar el email para el siguiente test
        $global:testEmail = $email
    }
} catch {
    Write-Host "✗ Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.ErrorDetails.Message) {
        Write-Host "Detalles: $($_.ErrorDetails.Message)" -ForegroundColor Red
    }
}

# ============================================
# TEST 3: Validar código 2FA
# ============================================
Write-Host "`n🔢 Validar código 2FA" -ForegroundColor Cyan
$code = Read-Host "Ingresa el código de 6 dígitos recibido por email"

if ($code) {
    try {
        $body = @{
            email = $email
            code = $code
        } | ConvertTo-Json
        
        $response = Invoke-RestMethod -Uri "$baseUrl/security/users/validate-2fa-code/" -Method Post -Body $body -ContentType "application/json"
        Write-Host "✓ Código validado exitosamente" -ForegroundColor Green
        $response | ConvertTo-Json -Depth 3
        
        # Guardar token
        if ($response.access) {
            $global:accessToken = $response.access
            Write-Host "`n✓ Token guardado en `$global:accessToken" -ForegroundColor Green
        }
    } catch {
        Write-Host "✗ Error: $($_.Exception.Message)" -ForegroundColor Red
        if ($_.ErrorDetails.Message) {
            Write-Host "Detalles: $($_.ErrorDetails.Message)" -ForegroundColor Red
        }
    }
}

# ============================================
# TEST 4: Registro de aprendiz
# ============================================
<#
Write-Host "`n👤 Registrar nuevo aprendiz" -ForegroundColor Cyan

$body = @{
    email = "nuevo.aprendiz@soy.sena.edu.co"
    first_name = "Nuevo"
    second_name = "Usuario"
    first_last_name = "Prueba"
    second_last_name = "Test"
    type_identification = 1  # 1 = Cédula de Ciudadanía
    number_identification = 1234567890
    phone_number = 3001234567
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$baseUrl/security/persons/register-apprentice/" -Method Post -Body $body -ContentType "application/json"
    Write-Host "✓ Registro exitoso" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 3
} catch {
    Write-Host "✗ Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.ErrorDetails.Message) {
        Write-Host "Detalles: $($_.ErrorDetails.Message)" -ForegroundColor Red
    }
}
#>

# ============================================
# TEST 5: Recuperar contraseña
# ============================================
<#
Write-Host "`n🔑 Solicitar recuperación de contraseña" -ForegroundColor Cyan

$body = @{
    email = "bscortes40@soy.sena.edu.co"
} | ConvertTo-Json

try {
    $response = Invoke-RestMethod -Uri "$baseUrl/security/users/request-password-reset/" -Method Post -Body $body -ContentType "application/json"
    Write-Host "✓ Solicitud enviada" -ForegroundColor Green
    $response | ConvertTo-Json -Depth 3
} catch {
    Write-Host "✗ Error: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.ErrorDetails.Message) {
        Write-Host "Detalles: $($_.ErrorDetails.Message)" -ForegroundColor Red
    }
}
#>

Write-Host "`n✅ Pruebas completadas" -ForegroundColor Green
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Gray
