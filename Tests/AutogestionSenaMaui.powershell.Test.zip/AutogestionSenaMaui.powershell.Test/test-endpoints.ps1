# Script de pruebas para los endpoints de la API
# Ejecutar desde PowerShell: .\test-endpoints.ps1

$baseUrl = "http://192.168.1.18:8000/api"

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "PRUEBAS DE ENDPOINTS - AutoGestión SENA" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Función para mostrar resultados
function Show-TestResult {
    param(
        [string]$TestName,
        [bool]$Success,
        [int]$StatusCode,
        [string]$Response
    )
    
    if ($Success) {
        Write-Host "[✓] $TestName" -ForegroundColor Green
        Write-Host "    Status: $StatusCode" -ForegroundColor Gray
    } else {
        Write-Host "[✗] $TestName" -ForegroundColor Red
        Write-Host "    Status: $StatusCode" -ForegroundColor Gray
    }
    
    if ($Response) {
        Write-Host "    Response:" -ForegroundColor Gray
        Write-Host "    $Response" -ForegroundColor Gray
    }
    Write-Host ""
}

# TEST 1: Obtener tipos de documento
Write-Host "TEST 1: Obtener tipos de documento (GET)" -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$baseUrl/security/document-types/" -Method Get -ContentType "application/json" -ErrorAction Stop
    $content = $response.Content | ConvertFrom-Json | ConvertTo-Json -Compress
    Show-TestResult -TestName "GET /security/document-types/" -Success $true -StatusCode $response.StatusCode -Response $content
} catch {
    Show-TestResult -TestName "GET /security/document-types/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -Response $_.Exception.Message
}

# TEST 2: Validar login institucional
Write-Host "TEST 2: Validar login institucional (POST)" -ForegroundColor Yellow
Write-Host "Ingresa las credenciales para probar:" -ForegroundColor Cyan
$email = Read-Host "Email institucional"
$password = Read-Host "Contraseña" -AsSecureString
$passwordPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($password))

try {
    $body = @{
        email = $email
        password = $passwordPlain
    } | ConvertTo-Json
    
    $response = Invoke-WebRequest -Uri "$baseUrl/security/users/validate-institutional-login/" -Method Post -Body $body -ContentType "application/json" -ErrorAction Stop
    $content = $response.Content | ConvertFrom-Json
    
    if ($content.error) {
        Show-TestResult -TestName "POST /security/users/validate-institutional-login/" -Success $false -StatusCode $response.StatusCode -Response $content.error
    } else {
        Show-TestResult -TestName "POST /security/users/validate-institutional-login/" -Success $true -StatusCode $response.StatusCode -Response "Login exitoso - Código 2FA enviado"
        
        # Guardar email para el siguiente test
        $script:loggedEmail = $email
    }
} catch {
    $errorContent = $_.ErrorDetails.Message
    Show-TestResult -TestName "POST /security/users/validate-institutional-login/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -Response $errorContent
}

# TEST 3: Validar código 2FA (solo si el login fue exitoso)
if ($script:loggedEmail) {
    Write-Host "TEST 3: Validar código de segundo factor (POST)" -ForegroundColor Yellow
    $code = Read-Host "Ingresa el código de 6 dígitos recibido por email"
    
    try {
        $body = @{
            email = $script:loggedEmail
            code = $code
        } | ConvertTo-Json
        
        $response = Invoke-WebRequest -Uri "$baseUrl/security/users/validate-2fa-code/" -Method Post -Body $body -ContentType "application/json" -ErrorAction Stop
        $content = $response.Content | ConvertFrom-Json | ConvertTo-Json -Compress
        Show-TestResult -TestName "POST /security/users/validate-2fa-code/" -Success $true -StatusCode $response.StatusCode -Response $content
    } catch {
        $errorContent = $_.ErrorDetails.Message
        Show-TestResult -TestName "POST /security/users/validate-2fa-code/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -Response $errorContent
    }
}

# TEST 4: Registro de aprendiz
Write-Host "TEST 4: Registro de aprendiz (POST)" -ForegroundColor Yellow
$testRegister = Read-Host "¿Deseas probar el registro de un nuevo aprendiz? (S/N)"

if ($testRegister -eq "S" -or $testRegister -eq "s") {
    Write-Host "Ingresa los datos del aprendiz:" -ForegroundColor Cyan
    $regEmail = Read-Host "Email institucional"
    $firstName = Read-Host "Primer nombre"
    $firstLastName = Read-Host "Primer apellido"
    $typeId = Read-Host "Tipo de documento (ID numérico, ej: 1 para CC)"
    $numberId = Read-Host "Número de documento"
    $phone = Read-Host "Teléfono"
    
    try {
        $body = @{
            email = $regEmail
            first_name = $firstName
            first_last_name = $firstLastName
            type_identification = [int]$typeId
            number_identification = [int]$numberId
            phone_number = [int]$phone
        } | ConvertTo-Json
        
        $response = Invoke-WebRequest -Uri "$baseUrl/security/persons/register-apprentice/" -Method Post -Body $body -ContentType "application/json" -ErrorAction Stop
        $content = $response.Content | ConvertFrom-Json | ConvertTo-Json -Compress
        Show-TestResult -TestName "POST /security/persons/register-apprentice/" -Success $true -StatusCode $response.StatusCode -Response $content
    } catch {
        $errorContent = $_.ErrorDetails.Message
        Show-TestResult -TestName "POST /security/persons/register-apprentice/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -Response $errorContent
    }
}

# TEST 5: Solicitud de recuperación de contraseña
Write-Host "TEST 5: Solicitud de recuperación de contraseña (POST)" -ForegroundColor Yellow
$testReset = Read-Host "¿Deseas probar la recuperación de contraseña? (S/N)"

if ($testReset -eq "S" -or $testReset -eq "s") {
    $resetEmail = Read-Host "Email institucional para recuperar contraseña"
    
    try {
        $body = @{
            email = $resetEmail
        } | ConvertTo-Json
        
        $response = Invoke-WebRequest -Uri "$baseUrl/security/users/request-password-reset/" -Method Post -Body $body -ContentType "application/json" -ErrorAction Stop
        $content = $response.Content | ConvertFrom-Json | ConvertTo-Json -Compress
        Show-TestResult -TestName "POST /security/users/request-password-reset/" -Success $true -StatusCode $response.StatusCode -Response $content
    } catch {
        $errorContent = $_.ErrorDetails.Message
        Show-TestResult -TestName "POST /security/users/request-password-reset/" -Success $false -StatusCode $_.Exception.Response.StatusCode.value__ -Response $errorContent
    }
}

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "PRUEBAS COMPLETADAS" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
